package newyeargift;

public class Badhshah extends Sweets {
	public Badhshah() {
		this.weight = 80; // grams
	}
}
