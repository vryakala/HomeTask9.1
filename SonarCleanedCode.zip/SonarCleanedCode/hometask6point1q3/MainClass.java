package hometask6point1q3;

import java.util.Date;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MainClass {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {
		HashMap<Employee, String> employeeMap = new HashMap<>();

		Employee employee1 = new Employee();
		employee1.setid(1);
		employee1.setname("sachin");
		employee1.setDOB(new Date(1987, 2, 1));
		employee1.setsalary(50000);

		employeeMap.put(employee1, "India");

		Employee employee2 = new Employee();
		employee2.setid(1);
		employee2.setname("sachin");
		employee2.setDOB(new Date(1987, 2, 1));
		employee2.setsalary(50000);

		employeeMap.put(employee2, "Japan");

		logger.log(Level.INFO, () -> "Employee map after adding Japan : " + employeeMap);
	}

}
