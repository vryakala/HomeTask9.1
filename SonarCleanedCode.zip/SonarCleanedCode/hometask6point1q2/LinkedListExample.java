package hometask6point1q2;

import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LinkedListExample {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {

		LinkedList<String> linkedlist = new LinkedList<>();

		// Adding elements to Linked List
		// This basically adds at the end of the list
		linkedlist.add("Item1");
		linkedlist.add("Item5");
		linkedlist.add("Item3");
		linkedlist.add("Item6");
		linkedlist.add("Item2");

		// Display Linked List Content
		logger.log(Level.INFO, () -> "Linked List Content: " + linkedlist);

		// Add First and Last Element
		linkedlist.addFirst("First Item");
		linkedlist.addLast("Last Item");
		logger.log(Level.INFO, () -> "LinkedList Content after addition: " + linkedlist);

		// Getting and setting Values
		Object firstvar = linkedlist.get(0);
		logger.log(Level.INFO, () -> "First element: " + firstvar);
		linkedlist.set(0, "Changed first item");
		Object firstvar2 = linkedlist.get(0);
		logger.log(Level.INFO, () -> "First element after update by set method: " + firstvar2);

		// Getting first and last elements
		Object firstele = linkedlist.getFirst();
		Object lastele = linkedlist.getLast();
		logger.log(Level.INFO, () -> "First element : " + firstele);
		logger.log(Level.INFO, () -> "Last element : " + lastele);

		/* Remove first and last element */
		linkedlist.removeFirst();
		linkedlist.removeLast();
		logger.log(Level.INFO, () -> "LinkedList after deletion of first and last element: " + linkedlist);

		/* Add to a Position and remove from a position */
		linkedlist.add(0, "Newly added item");
		linkedlist.remove(2);
		logger.log(Level.INFO, () -> "Final Content: " + linkedlist);

		// Adding elements from Array List to Linked List
		ArrayList<String> arraylist = new ArrayList<>();
		arraylist.add("String1");
		arraylist.add("String2");
		linkedlist.addAll(arraylist);

		logger.log(Level.INFO, () -> "Linked List Content after adding ArrayList Elements:" + linkedlist);

		// Cloning , copying elements of one list into other
		Object linkedlist1 = linkedlist.clone();

		logger.log(Level.INFO, () -> "linkedlist elements" + linkedlist);
		logger.log(Level.INFO, () -> "linkedlist1 elements" + linkedlist1);

		// Checking a element is present in the list
		boolean var = linkedlist.contains("TestString");
		boolean var1 = linkedlist.contains("Item2");

		logger.log(Level.INFO, () -> "linkedlist contains TestString" + var);
		logger.log(Level.INFO, () -> "linkedlist1 contains Item2" + var1);

		// Getting index of specified element
		int i = linkedlist.indexOf("Item1");

		logger.log(Level.INFO, () -> "Index of Item1" + i);

		// Getting index of last occurrence of specific element
		// Returns -1 on not finding the element
		int pos = linkedlist.lastIndexOf("hello");
		int pos1 = linkedlist.lastIndexOf("Item2");

		logger.log(Level.INFO, () -> "LastIndex of hello" + pos);
		logger.log(Level.INFO, () -> "LastIndex of Item2" + pos1);

		// Size of linked list
		int s = linkedlist.size();

		logger.log(Level.INFO, () -> "Size of linked list: " + s);

		// Removing all the elements from Linked List
		linkedlist.clear();

		logger.log(Level.INFO, () -> "Linked List content: " + linkedlist);
	}
}