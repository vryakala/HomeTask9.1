package hometask6point6;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Printer {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public <E> void printArray(E[] arr) {
		for (E element : arr)
			logger.log(Level.INFO, () -> "%s : " + element);
	}

	public static void main(String[] args) {
		Printer arr = new Printer();
		// create arrays of Integer, Double and Character
		Integer[] integerArray = { 1, 2, 3, 4, 5, 6 };
		Double[] doubleArray = { 1.1, 2.2, 3.3, 4.4, 5.5, 6.6, 7.7 };
		Character[] characterArray = { 'H', 'E', 'L', 'L', 'O' };
		logger.info("Array integerArray contains:");
		arr.printArray(integerArray); // pass an Integer array
		logger.info("\nArray doubleArray contains:");
		arr.printArray(doubleArray); // pass a Double array
		logger.info("\nArray characterArray contains:");
		arr.printArray(characterArray);
	}
}
