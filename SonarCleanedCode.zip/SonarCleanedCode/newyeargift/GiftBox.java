package newyeargift;

import java.util.ArrayList;

public class GiftBox {
	Chocolates chocolates = new Chocolates();
	Sweets sweets = new Sweets();
	ArrayList<Chocolates> chocolatesList = new ArrayList<>();
	ArrayList<Sweets> sweetsList = new ArrayList<>();
	ArrayList<Integer> chocolatesWeight = new ArrayList<>();
	ArrayList<Integer> sweetsWeight = new ArrayList<>();

	public void addChocolate(int n, Chocolates chocolates) {
		for (int i = 0; i < n; i++) {
			chocolatesList.add(chocolates);
			chocolatesWeight.add(chocolates.getWeight());
		}
	}

	public void addSweet(int n, Sweets sweets) {
		for (int i = 0; i < n; i++) {
			sweetsList.add(sweets);
			sweetsWeight.add(sweets.getWeight());
		}
	}
}
