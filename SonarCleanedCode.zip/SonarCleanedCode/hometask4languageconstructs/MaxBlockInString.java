package com.hometask4languageconstructs;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MaxBlockInString {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		logger.info("Enter String");
		String str = scanner.nextLine();
		scanner.close();
		int max = maxBlock(str);
		logger.log(Level.INFO, () -> "Max Bolck is : " + max);

	}

	private static int maxBlock(String str) {
		int i = 0;
		int j = 0;
		int k = 1;
		int max = 1;
		if (str == "") {
			return 0;
		} else {
			for (i = 0; i < str.length(); i++) {
				for (j = i + 1; j < str.length(); j++) {
					if (str.charAt(i) == str.charAt(j)) {
						k++;
						if (k > max)
							max = k;
					} else {
						k = 1;
						break;
					}
				}
				if (j == str.length())
					break;
			}
			return max;
		}
	}
}
