package hometask6point1q2;

import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ArrayListExample {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {

		ArrayList<String> arrlst = new ArrayList<>();

		// Adding elements to Array list
		arrlst.add("Ajeet");
		arrlst.add("Harry");
		arrlst.add("Chaitanya");
		arrlst.add("Steve");
		arrlst.add("Anuj");

		// Displaying elements in Array list
		logger.log(Level.INFO, () -> "Currently the array list : " + arrlst);

		// Add element at the given index
		arrlst.add(0, "Rahul");
		arrlst.add(1, "Justin");

		// Remove elements from Array list
		arrlst.remove("Chaitanya");
		arrlst.remove("Harry");

		logger.log(Level.INFO, () -> "Current ly the array list:" + arrlst);

		// Remove element from the given index
		arrlst.remove(1);

		logger.log(Level.INFO, () -> "Currently the array list:" + arrlst);

		// Update an element at a given index
		arrlst.set(2, "Tom");

		logger.log(Level.INFO, () -> "Currently the array list:" + arrlst);

		// Getting index of an object
		// If the element is not found in the list then this method returns the
		// value -1.
		int pos = arrlst.indexOf("Tom");

		logger.log(Level.INFO, () -> "Index of TOM is:" + pos);
		// To get object at a specific index
		String str = arrlst.get(2);

		logger.log(Level.INFO, () -> "Object present at index 2 is:" + str);

		// Size of array list
		int numberofitems = arrlst.size();

		logger.log(Level.INFO, () -> "Size:" + numberofitems);

		// Check if a object is present in the array list
		boolean b1 = arrlst.contains("Tom");
		logger.log(Level.INFO, () -> "contains Tom : " + b1);
		boolean b2 = arrlst.contains("Harry");
		logger.log(Level.INFO, () -> "Contains Harry : " + b2);

		// Remove all elements of array list in one go
		arrlst.clear();

		logger.log(Level.INFO, () -> "Current array list is:" + arrlst);
	}
}
