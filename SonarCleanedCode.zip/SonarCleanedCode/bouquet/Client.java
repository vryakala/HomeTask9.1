package bouquet;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Client {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {
		Bouquet bouquetName = new Bouquet();
		bouquetName.add(5, new Rose());
		bouquetName.add(5, new Lilly());
		logger.log(Level.INFO, () -> "Cost of Bouquet is " + costOfBouquet());
	}

	private static int costOfBouquet() {
		int cost = 0;
		for (Flower flower : Bouquet.list) {
			cost = cost + flower.cost;
		}
		return cost;
	}
}
