package hometask6point1q2;

import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Set;
import java.util.Iterator;
import java.util.Map;

public class TreeMapExample {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {

		/* This is how to declare TreeMap */
		TreeMap<Integer, String> tmap = new TreeMap<>();

		/* Adding elements to TreeMap */
		tmap.put(1, "Data1");
		tmap.put(23, "Data2");
		tmap.put(70, "Data3");
		tmap.put(4, "Data4");
		tmap.put(2, "Data5");

		/* Display content using Iterator */
		logger.info("Content of TreeMap:");
		Set set = tmap.entrySet();
		Iterator iterator = set.iterator();
		while (iterator.hasNext()) {
			Map.Entry mentry = (Map.Entry) iterator.next();
			logger.log(Level.INFO, () -> "key is: " + mentry.getKey() + " & Value is: " + mentry.getValue());
		}

		// REmoving a element
		tmap.remove(1);
		logger.info("Content of TreeMap After removal:");
		Set set1 = tmap.entrySet();
		Iterator iterator1 = set1.iterator();
		while (iterator1.hasNext()) {
			Map.Entry mentry = (Map.Entry) iterator1.next();
			logger.log(Level.INFO, () -> "key is: " + mentry.getKey() + " & Value is: " + mentry.getValue());
		}

		// Size of the TreeSet
		int s = tmap.size();
		logger.log(Level.INFO, () -> "Size-is:" + s);

		// Checking a element in tree set
		boolean b1 = tmap.containsKey(23);
		boolean b2 = tmap.containsValue("Jim");

		logger.log(Level.INFO, () -> "containsKey 23 :" + b1);
		logger.log(Level.INFO, () -> "containsValue JIM :" + b2);
	}
}