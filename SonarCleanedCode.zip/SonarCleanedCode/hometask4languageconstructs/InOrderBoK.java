package com.hometask4languageconstructs;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class InOrderBoK {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		logger.info("Enter First Number");
		int a = scanner.nextInt();
		logger.info("Enter Second Number");
		int b = scanner.nextInt();
		logger.info("Enter Third Number");
		int c = scanner.nextInt();
		logger.info("Enter bOk");
		boolean bOk = scanner.nextBoolean();
		scanner.close();
		boolean i = inOrder(a, b, c, bOk);
		logger.log(Level.INFO, () -> "Final String is : " + i);
	}

	private static boolean inOrder(int a, int b, int c, boolean bOk) {
		if (c > b && bOk)
			return true;
		if (c > b && b > a)
			return true;
		return false;
	}
}
