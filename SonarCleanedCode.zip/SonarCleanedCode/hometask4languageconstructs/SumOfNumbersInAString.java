package com.hometask4languageconstructs;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SumOfNumbersInAString {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		logger.info("Enter a String");
		String s = scanner.nextLine();
		scanner.close();
		int i = sumNumbers(s);
		logger.log(Level.INFO, () -> "Sum is : " + i);
	}

	private static int sumNumbers(String str) {
		int sum = 0;
		int i = 0;
		int begin;
		int end;

		while (i < str.length() && !Character.isDigit(str.charAt(i)))
			i++;

		begin = i;
		end = i;

		while (i < str.length()) {
			if (!Character.isDigit(str.charAt(i))) {
				sum += Integer.parseInt(str.substring(begin, end));
				while (i < str.length() && !Character.isDigit(str.charAt(i)))
					i++;

				begin = i;
				end = i;
			} else {
				end++;
				i++;
			}
		}

		if (end > begin)
			sum += Integer.parseInt(str.substring(begin, end));

		return sum;
	}
}
