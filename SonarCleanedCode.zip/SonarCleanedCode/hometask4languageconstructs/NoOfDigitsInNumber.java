package com.hometask4languageconstructs;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class NoOfDigitsInNumber {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		logger.info("Enter a number between 10-99");
		int a = scanner.nextInt();
		logger.info("Enter a number between 10-99");
		int b = scanner.nextInt();
		scanner.close();
		if (a > 0 && b > 0) {
			int i = sumLimit(a, b);
			logger.log(Level.INFO, () -> "Sum is : " + i);
		} else {
			logger.info("Enter Positive Numbers only");
		}
	}

	private static int sumLimit(int a, int b) {
		String str1 = Integer.toString(a);
		int l1 = str1.length();
		int c = a + b;
		String str3 = Integer.toString(c);
		int l3 = str3.length();
		if (l3 > l1)
			return a;
		else
			return c;
	}
}
