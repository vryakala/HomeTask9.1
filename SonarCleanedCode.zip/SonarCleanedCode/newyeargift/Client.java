package newyeargift;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Client {
	private static final Logger logger = Logger.getLogger("InfoLogging");
	static GiftBox childGift = new GiftBox();

	public static void main(String[] args) {

		childGift.addChocolate(2, new DairyMilk());
		childGift.addChocolate(2, new Snickers());
		childGift.addSweet(1, new Laddu());
		childGift.addSweet(2, new Badhshah());
		logger.log(Level.INFO, () -> "Total weight of Childern's Gift = " + totalWeight1());
	}

	private static int totalWeight1() {
		int totalweight1 = 0;
		int chocoweight1 = 0;
		int sweetweight1 = 0;
		for (Chocolates chocolates : childGift.chocolatesList) {
			chocoweight1 = chocoweight1 + chocolates.weight;
		}
		for (Sweets sweets : childGift.sweetsList) {
			sweetweight1 = sweetweight1 + sweets.weight;
		}
		totalweight1 = chocoweight1 + sweetweight1;
		return totalweight1;

	}
}
