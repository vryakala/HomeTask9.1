package bouquet;

public class Rose extends Flower {
	public Rose() {
		this.cost = 5;
	}
}
