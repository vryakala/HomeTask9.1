package com.hometask4loopsandarrays;

import java.util.Scanner;
import java.util.logging.*;

public class Clumps {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int len = scanner.nextInt();
		logger.info("Length of Array entered from commandlind");
		int arr[] = new int[len];
		for (int i = 0; i < len; i++)
			arr[i] = scanner.nextInt();
		scanner.close();
		logger.info("Array of numbers entered from commandlind");
		int clump = countClumps(arr);
		logger.log(Level.INFO, () -> "Calculated and number of Clumps are:-" + clump);
	}

	private static int countClumps(int[] arr) {
		int count = 0;
		int i = 0;

		while (i < arr.length) {
			int val = arr[i];
			i++;
			int length = 1;
			while (i < arr.length && arr[i] == val) {
				i++;
				length++;
			}
			if (length > 1)
				count++;
		}
		return count;
	}
}