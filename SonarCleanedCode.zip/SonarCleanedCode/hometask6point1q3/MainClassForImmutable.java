package hometask6point1q3;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MainClassForImmutable {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {

		HashMap<EmployeeImmutable, String> employeeMap = new HashMap<>();

		EmployeeImmutable employee1 = EmployeeImmutable.EmployeeBuilder.anEmployee().withId(1).withName("Sachin")
				.withDateOfBirth(new Date(1987, 2, 1)).withSalary(100000).build();

		employeeMap.put(employee1, "India");

		for (Map.Entry<EmployeeImmutable, String> employeeStringEntry : employeeMap.entrySet()) {
			logger.log(Level.INFO,
					() -> "employeeStringEntry.getKey().hashCode() is : " + employeeStringEntry.getKey().hashCode());

		}

		EmployeeImmutable immutableUpdatedEmployee1 = EmployeeImmutable.EmployeeBuilder.anEmployee(employee1)
				.withName("Rahul").build();

		for (Map.Entry<EmployeeImmutable, String> employeeStringEntry : employeeMap.entrySet()) {

			logger.log(Level.INFO,
					() -> "employeeStringEntry.getKey().hashCode() is : " + employeeStringEntry.getKey().hashCode());

		}
		logger.log(Level.INFO,
				() -> "employeeMap.get(immutableUpdatedEmployee1) is : " + employeeMap.get(immutableUpdatedEmployee1));

		// Returns null

		EmployeeImmutable employee2 = EmployeeImmutable.EmployeeBuilder.anEmployee().withId(1).withName("Sachin")
				.withDateOfBirth(new Date(1987, 2, 1)).withSalary(100000).build();

		logger.log(Level.INFO, () -> "employee2.hashCode() is : " + employee2.hashCode());

		logger.log(Level.INFO, () -> "employeeMap.get(employee2) is : " + employeeMap.get(employee2));

		// Now this works fine and it shall return the correct object from the
		// HashMap

	}
}