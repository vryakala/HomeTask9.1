package hometask6point1q3;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MainClass1 {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {

		// Employee is a mutable object. That will create problems with a
		// HashMap.

		HashMap<Employee, String> employeeMap = new HashMap<>();

		Employee employee1 = new Employee();
		employee1.setid(1);
		employee1.setname("sachin");
		employee1.setDOB(new Date(1987, 2, 1));
		employee1.setsalary(50000);

		employeeMap.put(employee1, "India");

		for (Map.Entry<Employee, String> employeeStringEntry : employeeMap.entrySet()) {
			logger.log(Level.INFO,
					() -> "employeeStringEntry.getKey().hashCode() : " + employeeStringEntry.getKey().hashCode());

		}

		// Mutating the Employee Object
		employee1.setname("Rahul");

		for (Map.Entry<Employee, String> employeeStringEntry : employeeMap.entrySet()) {
			logger.log(Level.INFO,
					() -> "employeeStringEntry.getKey().hashCode() : " + employeeStringEntry.getKey().hashCode());
		}

		// The HashMap key is mutated and in the wrong bucket for that hashcode.

		logger.log(Level.INFO, () -> "EmployeeMap.get(employee1) : " + employeeMap.get(employee1));

		Employee employee2 = new Employee();
		employee2.setid(1);
		employee2.setname("sachin");
		employee2.setDOB(new Date(1987, 2, 1));
		employee2.setsalary(50000);

		logger.log(Level.INFO, () -> "EmployeeMap.get(employee2) : " + employeeMap.get(employee2));

		// Once the employee object is mutated, the hashcode of that object is
		// going to change

		// Now if we try to retrieve the object,(it has different hashcode) it
		// will go to a different bucket and will not be able to get the value.

		// Now the object placed in the hashmap is lost forever.
	}

}