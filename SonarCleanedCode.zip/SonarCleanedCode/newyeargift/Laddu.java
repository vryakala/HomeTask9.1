package newyeargift;

public class Laddu extends Sweets {
	public Laddu() {
		this.weight = 150; // grams
	}
}
