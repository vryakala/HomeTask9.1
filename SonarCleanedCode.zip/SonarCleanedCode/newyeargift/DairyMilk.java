package newyeargift;

public class DairyMilk extends Chocolates {
	public DairyMilk() {
		this.weight = 100; // grams
	}
}
