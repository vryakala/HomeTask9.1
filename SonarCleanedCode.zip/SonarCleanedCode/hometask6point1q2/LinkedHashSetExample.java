package hometask6point1q2;

import java.util.LinkedHashSet;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LinkedHashSetExample {

	// LinkedHashSet maintains the insertion order. Elements gets sorted in the
	// same sequence in which they have been added to the Set.
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {

		LinkedHashSet<String> lhset = new LinkedHashSet<>();

		// Adding elements to the LinkedHashSet
		lhset.add("Z");
		lhset.add("PQ");
		lhset.add("N");
		lhset.add("O");
		lhset.add("KK");
		lhset.add("FGH");
		logger.log(Level.INFO, () -> "LinkedHash Set is : " + lhset);

		// LinkedHashSet of Integer Type
		LinkedHashSet<Integer> lhset2 = new LinkedHashSet<>();

		// Adding elements
		lhset2.add(99);
		lhset2.add(7);
		lhset2.add(0);
		lhset2.add(67);
		lhset2.add(89);
		lhset2.add(66);
		logger.log(Level.INFO, () -> "LinkedHashSet is : " + lhset2);

		// REmoving a element
		lhset.remove("Z");
		logger.log(Level.INFO, () -> "LinkedHashSet is : " + lhset);

		// Size of the TreeSet
		int s = lhset.size();
		logger.log(Level.INFO, () -> "Size is:" + s);

		// Checking a element in tree set
		boolean b1 = lhset.contains("N");
		logger.log(Level.INFO, () -> "LinkedHashSet contains N : " + b1);
	}
}