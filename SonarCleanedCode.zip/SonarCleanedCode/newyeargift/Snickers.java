package newyeargift;

public class Snickers extends Chocolates {
	public Snickers() {
		this.weight = 100; // grams
	}
}
