package hometask6point1q2;

import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

public class HashMapExample {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {

		HashMap<Integer, String> hmap = new HashMap<>();

		// Adding elements to HashMap
		hmap.put(12, "Chaitanya");
		hmap.put(2, "Rahul");
		hmap.put(7, "Singh");
		hmap.put(49, "Ajeet");
		hmap.put(3, "Anuj");

		// Display HashMap content using Iterator
		Set set = hmap.entrySet();
		Iterator iterator = set.iterator();
		while (iterator.hasNext()) {
			Map.Entry mentry = (Map.Entry) iterator.next();
			logger.log(Level.INFO, () -> "key is: " + mentry.getKey() + " & Value is: " + mentry.getValue());
		}

		// Get values based on key
		String var = hmap.get(2);
		logger.log(Level.INFO, () -> "Value at index 2 is: " + var);

		// Remove values based on key
		hmap.remove(3);
		logger.info("Map key and values after removal:");
		Set set2 = hmap.entrySet();
		Iterator iterator2 = set2.iterator();
		while (iterator2.hasNext()) {
			Map.Entry mentry2 = (Map.Entry) iterator2.next();
			logger.log(Level.INFO, () -> "key is: " + mentry2.getKey() + " & Value is: " + mentry2.getValue());
		}
	}
}