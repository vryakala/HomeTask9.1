package bouquet;

public class Lilly extends Flower {
	public Lilly() {
		this.cost = 7;
	}
}
