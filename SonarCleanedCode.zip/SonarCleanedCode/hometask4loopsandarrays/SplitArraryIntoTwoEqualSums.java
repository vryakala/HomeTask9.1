package com.hometask4loopsandarrays;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SplitArraryIntoTwoEqualSums {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		logger.info("Enter length of array");
		int len = scanner.nextInt();
		int arr[] = new int[len];
		logger.info("Enter array elements");
		for (int i = 0; i < len; i++)
			arr[i] = scanner.nextInt();
		scanner.close();
		boolean b = canBalance(arr);
		logger.log(Level.INFO, () -> "Can balance = " + b);
	}

	private static boolean canBalance(int[] arr) {
		int sum1 = 0;
		int sum2 = 0;
		for (int i = 0; i < arr.length; i++) {
			sum1 = sum1 + arr[i];
			for (int j = arr.length - 1; j > i; j--) {
				sum2 = sum2 + arr[j];
			}
			if (sum1 == sum2)
				return true;
			sum2 = 0;
		}
		return false;
	}

}
