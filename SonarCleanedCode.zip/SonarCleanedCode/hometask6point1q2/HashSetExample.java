package hometask6point1q2;

import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;

public class HashSetExample {

	// HashSet doesn�t maintain any order, the elements would be returned in any
	// random order.

	// HashSet doesn�t allow duplicates. If you try to add a duplicate element
	// in HashSet, the old value would be overwritten.

	// HashSet allows null values however if you insert more than one nulls it
	// would still return only one null value.

	// HashSet is non-synchronized.

	// The iterator returned by this class is fail-fast which means iterator
	// would throw ConcurrentModificationException if HashSet has been modified
	// after creation of iterator, by any means except iterator�s own remove
	// method.
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {
		// HashSet declaration
		HashSet<String> hset = new HashSet<>();

		// Adding elements to the HashSet
		hset.add("Apple");
		hset.add("Mango");
		hset.add("Grapes");
		hset.add("Orange");
		hset.add("Fig");
		// Addition of duplicate elements
		hset.add("Apple");
		hset.add("Mango");
		// Addition of null values
		hset.add(null);
		hset.add(null);

		// Displaying HashSet elements
		logger.log(Level.INFO, () -> "Hash Set is : " + hset);

		// Size of the Hash set
		int s = hset.size();
		logger.log(Level.INFO, () -> "Size is:" + s);

		// Check if a element is present in the hash set
		boolean b = hset.contains("Apple");
		boolean b1 = hset.contains("Apple1");
		logger.log(Level.INFO, () -> "Contains Apple :" + b);
		logger.log(Level.INFO, () -> "Contains Apple1:" + b1);

		// removing a element
		hset.remove("Fig");
		logger.log(Level.INFO, () -> "HashSet after Removing Fig:" + hset);

		HashSet<String> hset1 = (HashSet<String>) hset.clone();
		logger.log(Level.INFO, () -> "Cloned Hashset:" + hset1);

		// Remove all the elements
		hset.clear();
		logger.log(Level.INFO, () -> "Cloned Hashset:" + hset);
	}
}