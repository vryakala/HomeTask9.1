package com.hometask4loopsandarrays;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class InnerAndOuterArrays {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		logger.info("Enter outer array length");
		int outerlen = scanner.nextInt();
		logger.info("Outer Array length entered from command line");
		logger.info("Enter outer array elements");
		int outarr[] = new int[outerlen];
		logger.info("Outer Array Elements entered from command line");
		for (int i = 0; i < outerlen; i++)
			outarr[i] = scanner.nextInt();
		logger.info("Enter Inner array length");
		int innerlen = scanner.nextInt();
		logger.info("Inner Array length entered from command line");
		logger.info("Enter outer array elements");
		int inarr[] = new int[innerlen];
		logger.info("Inner Array Elements entered from command line");
		for (int i = 0; i < innerlen; i++)
			inarr[i] = scanner.nextInt();
		scanner.close();
		boolean b = linearIn(outarr, inarr);
		logger.log(Level.INFO, () -> "Present = " + b);
	}

	private static boolean linearIn(int[] outer, int[] inner) {
		int count = 0;
		int j = 0;
		if (inner.length == 0)
			return true;
		for (int i = 0; i < outer.length; i++) {
			if (outer[i] == inner[j]) {
				count++;
				j++;
			} else if (outer[i] > inner[j]) {
				return false;
			}
			if (count == inner.length) {
				return true;
			}
		}
		return false;

	}
}