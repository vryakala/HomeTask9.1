package com.hometask4loopsandarrays;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MirrorSelection {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		logger.info("Enter length of array");
		int len = scanner.nextInt();
		int arr[] = new int[len];
		logger.info("Enter array elements");
		for (int i = 0; i < len; i++)
			arr[i] = scanner.nextInt();
		scanner.close();
		int i = maxMirror(arr);
		logger.log(Level.INFO, () -> "Max Mirror length= " + i);
	}

	private static int maxMirror(int[] arr) {
		String substr = "";
		int maxlength = 0;
		int count = 0;
		String str = "";

		for (int i = 0; i < arr.length; i++) {
			str = str.concat(Integer.toString(arr[i]));
		}

		String reverse = "";

		for (int i = arr.length - 1; i >= 0; i--) {
			reverse = reverse.concat(Integer.toString(arr[i]));
		}

		for (int i = -1; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				substr = substr.concat(Integer.toString(arr[j]));

				if (reverse.contains(substr)) {
					count++;
					if (count > maxlength) {
						maxlength = count;
					}
				}
			}
			count = 0;
			substr = "";
		}
		return maxlength;
	}

}
