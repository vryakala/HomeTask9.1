package com.hometask4languageconstructs;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DeleteSringFromString {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		logger.info("Enter Base String");
		String base = scanner.nextLine();
		logger.info("Enter remove string");
		String remove = scanner.nextLine();
		if (base == null || remove == null)
			logger.info("enter Not null values");
		else {
			String str = withoutString(base, remove);
			logger.log(Level.INFO, () -> "Final String is : " + str);
		}
		scanner.close();
	}

	private static String withoutString(String base, String remove) {
		int blen = base.length();
		int rlen = remove.length();
		String lowbase = base.toLowerCase();
		String lowrem = remove.toLowerCase();
		StringBuilder sb = new StringBuilder();
		String ste;

		for (int i = 0; i < blen; i++) {
			if (i <= blen - rlen) {
				String tmp = lowbase.substring(i, i + rlen);
				if (!tmp.equals(lowrem))
					sb.append(base.substring(i, i + 1));
				else {
					i += rlen - 1;
				}
			} else {
				String tmp2 = lowbase.substring(i, i + 1);
				if (!tmp2.equals(lowrem))
					sb.append(base.substring(i, i + 1));
			}
		}
		ste = sb.toString();
		return ste;
	}
}
