package com.hometask4languageconstructs;

import java.util.Scanner;
import java.util.logging.Logger;

public class SixAGreatNumber {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		logger.info("Enter First Number");
		int a = scanner.nextInt();
		logger.info("Enter Second Number");
		int b = scanner.nextInt();
		scanner.close();
		if (a == 6 || b == 6 || (a - b) == 6 || (a + b) == 6)
			logger.info("true");
		else
			logger.info("false");
	}

}
