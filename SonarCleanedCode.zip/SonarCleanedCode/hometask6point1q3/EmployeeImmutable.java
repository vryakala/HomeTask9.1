package hometask6point1q3;

import java.util.Date;

public final class EmployeeImmutable {

	private final int id;
	private final String name;
	private final Date dob;
	private final int salary;

	public EmployeeImmutable(EmployeeBuilder employeeBuilder) {
		this.id = employeeBuilder.id;
		this.name = employeeBuilder.name;
		this.dob = employeeBuilder.dob;
		this.salary = employeeBuilder.salary;
	}

	public int getid() {
		return id;
	}

	public String getname() {
		return name;
	}

	public Date getDOB() {
		return dob;
	}

	public int getsalary() {
		return salary;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", DOB=" + dob + ", salary=" + salary + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dob == null) ? 0 : dob.hashCode());
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + salary;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeImmutable other = (EmployeeImmutable) obj;
		if (dob == null) {
			if (other.dob != null)
				return false;
		} else if (!dob.equals(other.dob)) {
			return false;
		}
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name)) {
			return false;
		}
		if (salary != other.salary) {
			return false;
		}
		return true;
	}

	public static final class EmployeeBuilder {

		private int id;
		private String name;
		private Date dob;
		private int salary;

		private EmployeeBuilder() {

		}

		public static EmployeeBuilder anEmployee() {
			return new EmployeeBuilder();
		}

		public static EmployeeBuilder anEmployee(EmployeeImmutable employee) {
			return anEmployee().withId(employee.getid()).withName(employee.getname()).withDateOfBirth(employee.getDOB())
					.withSalary(employee.getsalary());
		}

		public EmployeeBuilder withId(int id) {
			this.id = id;
			return this;

		}

		public EmployeeBuilder withName(String name) {
			this.name = name;
			return this;
		}

		public EmployeeBuilder withDateOfBirth(Date dateOfBirth) {
			this.dob = dob;
			return this;
		}

		public EmployeeBuilder withSalary(int salary) {
			this.salary = salary;
			return this;

		}

		public EmployeeImmutable build() {
			return new EmployeeImmutable(this);

		}

	}

}
