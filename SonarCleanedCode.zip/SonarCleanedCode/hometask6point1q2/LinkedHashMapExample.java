package hometask6point1q2;

import java.util.LinkedHashMap;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Map;

public class LinkedHashMapExample {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {
		// HashMap Declaration
		LinkedHashMap<Integer, String> lhmap = new LinkedHashMap<>();

		// Adding elements to LinkedHashMap
		lhmap.put(22, "Abey");
		lhmap.put(33, "Dawn");
		lhmap.put(1, "Sherry");
		lhmap.put(2, "Karon");
		lhmap.put(100, "Jim");

		// Displaying elements of Linked HashMap
		for (Map.Entry<Integer, String> entry : lhmap.entrySet()) {
			int key = entry.getKey();
			String value = entry.getValue();
			logger.log(Level.INFO, () -> key + " : " + value);
		}

		// Getting values based on key
		String text = lhmap.get(33);
		logger.log(Level.INFO, () -> "Value with key 33 is : " + text);

		// Prints NULL if the key doesn't exist in the map
		String text1 = lhmap.get(4);

		logger.log(Level.INFO, () -> "Value with key 4 is : " + text1);

		// If you add a duplicate key, the earlier one will get overwritten
		lhmap.put(1, "Hello");

		String text2 = lhmap.get(1);

		logger.log(Level.INFO, () -> "Value with key 1 is : " + text2);
		logger.info("Map key and values:");
		// Iterating through Hash map
		for (Map.Entry<Integer, String> entry : lhmap.entrySet()) {
			int key = entry.getKey();
			String value = entry.getValue();
			logger.log(Level.INFO, () -> key + " : " + value);
		}

		/* Remove values based on key */
		lhmap.remove(1);
		logger.info("Map key and values after removal:");

		// Iterating through Linked Hash map
		for (Map.Entry<Integer, String> entry : lhmap.entrySet()) {
			int key = entry.getKey();
			String value = entry.getValue();
			logger.log(Level.INFO, () -> key + " : " + value);
		}

		// Checking whether Keys and Values are present in the Linked HashMap
		boolean b1 = lhmap.containsKey(33);
		boolean b2 = lhmap.containsValue("Jim");

		logger.log(Level.INFO, () -> "Contains key 33 : " + b1);
		logger.log(Level.INFO, () -> "Contains value JIM : " + b2);

		// Getting all the keys
		Set set1 = lhmap.keySet();
		logger.log(Level.INFO, () -> "Keys are:" + set1);

		// Getting all the values
		logger.log(Level.INFO, () -> "Values are : " + lhmap.values());

		// Cloning a Linked hash map
		LinkedHashMap<Integer, String> lhmap1 = (LinkedHashMap<Integer, String>) lhmap.clone();
		logger.info("Values in Cloned map:");
		for (Map.Entry<Integer, String> entry : lhmap1.entrySet()) {
			int key = entry.getKey();
			String value = entry.getValue();
			logger.log(Level.INFO, () -> key + " : " + value);
		}

		// Deleting all the values from Linked Hash map
		lhmap.clear();
	}
}