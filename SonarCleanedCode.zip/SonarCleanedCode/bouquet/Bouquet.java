package bouquet;

import java.util.ArrayList;

public class Bouquet {
	// Creating flower object
	Flower flower = new Flower();
	static ArrayList<Flower> list = new ArrayList<>();

	public void add(int n, Flower flower) {
		for (int i = 0; i < n; i++) {
			list.add(flower);
		}
		// System.out.println("Added " + n + " " + Flower.getClass() + " Flowers
		// to Bouquet");
		// System.out.println(list);
	}

}
