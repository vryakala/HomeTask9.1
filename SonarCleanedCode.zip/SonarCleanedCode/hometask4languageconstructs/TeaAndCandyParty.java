package com.hometask4languageconstructs;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TeaAndCandyParty {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		logger.info("Enter Tea Amount");
		int tea = scanner.nextInt();
		logger.info("Enter Candy Amount");
		int candy = scanner.nextInt();
		scanner.close();
		int i = teaParty(tea, candy);
		logger.log(Level.INFO, () -> "Result is : " + i);
	}

	private static int teaParty(int tea, int candy) {
		if (tea < 5 || candy < 5)
			return 0;
		if (tea >= 5 || candy >= 5) {
			if (tea >= (2 * candy) || candy >= (2 * tea))
				return 2;
			return 1;
		}

		return candy;
	}

}
