package hometask6point1q2;

import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TreeSetExample {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	public static void main(String[] args) {

		TreeSet<String> tset = new TreeSet<>();
		tset.add("ABC");
		tset.add("String");
		tset.add("Test");
		tset.add("Pen");
		tset.add("Ink");
		tset.add("Jack");

		logger.log(Level.INFO, () -> "TreeSet is : " + tset);

		TreeSet<Integer> tset2 = new TreeSet<>();

		tset2.add(88);
		tset2.add(7);
		tset2.add(101);
		tset2.add(0);
		tset2.add(3);
		tset2.add(222);

		logger.log(Level.INFO, () -> "TreeSet is : " + tset2);

		// REmoving a element
		tset.remove("ABC");
		logger.log(Level.INFO, () -> "TreeSet is after removing: " + tset2);

		// Size of the TreeSet
		int s = tset.size();
		logger.log(Level.INFO, () -> "Size is:" + s);

		// Returning first element in the set order
		String s1 = tset.first();
		logger.log(Level.INFO, () -> "First Element:" + s1);

		// Returning last element in the set order
		String s2 = tset.last();
		logger.log(Level.INFO, () -> "Last Element:" + s2);

		// Checking a element in tree set
		boolean b1 = tset.contains("Ink");
		logger.log(Level.INFO, () -> "Contains Ink:" + b1);
	}
}
