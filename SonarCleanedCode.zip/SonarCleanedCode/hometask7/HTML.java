package hometask7;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Logger;

public class HTML {
	private static final Logger logger = Logger.getLogger("InfoLogging");

	static File file = new File("D:\\DirInfo.html");

	public static void main(String[] args) {
		try {
			boolean fvar = file.createNewFile();
			if (fvar) {
				logger.info("File has been created successfully");
			} else {
				logger.info("File already present at the specified location");
			}
			File dir = new File("D:\\Bills");
			getFileDetails(dir);
		} catch (IOException e) {
			logger.info("Exception Occurred:");
			e.printStackTrace();
		}
	}

	private static void getFileDetails(File dir) throws IOException {
		File[] filesList = dir.listFiles();
		ArrayList<String> directoryNames = new ArrayList<>();
		ArrayList<String> fileNames = new ArrayList<>();
		ArrayList<Long> directorySize = new ArrayList<>();
		ArrayList<Long> fileSize = new ArrayList<>();
		ArrayList<String> directoryCreatedDates = new ArrayList<>();
		ArrayList<String> fileCreatedDates = new ArrayList<>();

		for (File f : filesList) {
			if (f.isDirectory()) {
				directoryNames.add(f.getName());
				directorySize.add(getFolderSize(f));
			}
			if (f.isFile()) {
				fileNames.add(f.getName());
				fileSize.add(f.length() / 1024);
			}
		}

		BufferedWriter bw = new BufferedWriter(new FileWriter(file));
		try {
			bw.write(
					"<html><head><style>table, th, td {border: 1px solid black;}</style></head><body><table><tr><th>Name</th><th>Type</th><th>Creation Date</th><th>Size (in Kb)</th></tr>");
			bw.write("</table></body></html>");

		} catch (IOException e) {
			logger.info("Exception Occured");
			e.printStackTrace();
		} finally {
			bw.close();
		}
	}

	private static long getFolderSize(File folder) {
		long length = 0;
		File[] files = folder.listFiles();
		int count = files.length;
		for (int i = 0; i < count; i++) {
			if (files[i].isFile()) {
				length += files[i].length();
			} else {
				length += getFolderSize(files[i]);
			}
		}
		return length;
	}
}